import { fakeAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { LayoutMultiComponent } from './layout-multi.component';

describe('LayoutMultiComponent', () => {
  let component: LayoutMultiComponent;
  let fixture: ComponentFixture<LayoutMultiComponent>;

  beforeEach(fakeAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ LayoutMultiComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LayoutMultiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should compile', () => {
    expect(component).toBeTruthy();
  });
});
