import { Component  } from '@angular/core';
import { NzResizeEvent } from 'ng-zorro-antd/resizable';


@Component({
  selector: 'app-layout-multi',
  templateUrl: './layout-multi.component.html',
  styleUrls: ['./layout-multi.component.css']
})
export class LayoutMultiComponent  {




  siderWidth = 120;
  contentHeight = 200;
  id = -1;
  checkal = false;
  checkprj = false;

private screenWidth: number;
private screenHeight: number;


  onSideResize({ width }: NzResizeEvent): void {
    cancelAnimationFrame(this.id);
    this.id = requestAnimationFrame(() => {
      // tslint:disable-next-line: no-non-null-assertion
      this.siderWidth = width!;
    });
  }

  onContentResize({ height }: NzResizeEvent): void {
    cancelAnimationFrame(this.id);
    this.id = requestAnimationFrame(() => {
      // tslint:disable-next-line: no-non-null-assertion
      this.contentHeight = height!;
    });

  }

  onResize(event?) {
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
 }
  minimizeOption(): void {
    console.log('console logged');
    this.checkal = !this.checkal;
    console.log(this.screenHeight );
    this.screenHeight = window.innerWidth;
    console.log('console logged');
  }

  loadOne(): void {
    this.screenHeight = window.innerHeight -  64 ;
    console.log('Test Text Added');
    console.log(this.screenHeight );
    this.checkal = !this.checkal;
    this.contentHeight = this.screenHeight  ;

    if (this.checkal ) {
      this.contentHeight  = this.contentHeight / 2;
    }
  }


}
